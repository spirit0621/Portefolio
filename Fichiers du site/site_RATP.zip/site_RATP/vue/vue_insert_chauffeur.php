<h3> Ajout d'un chauffeur </h3>
<form method="post">
	<table>
		<tr>
			<td> Nom </td>
			<td> <input type="text" name="nom"></td>
		</tr>
		<tr>
			<td> Prénom </td>
			<td> <input type="text" name="prenom"></td>
		</tr>
		<tr>
			<td> Email </td>
			<td> <input type="text" name="email"></td>
		</tr>
		<tr>
			<td> MDP </td>
			<td> <input type="password" name="mdp"></td>
		</tr>
		<tr>
			<td> Adresse </td>
			<td> <input type="text" name="adresse"></td>
		</tr>
		<tr>
			<td> <input type="reset" name="Annuler" value="Annuler"> </td>
			<td> <input type="submit" name="Valider" value="Valider"></td>
		</tr>
	</table> 
</form>
