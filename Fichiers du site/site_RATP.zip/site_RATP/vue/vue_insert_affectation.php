<h3> Ajout d'une affectation </h3>
<form method="post">
	<table>
		<tr>
			<td> Description </td>
			<td> <input type="text" name="description"></td>
		</tr>
		<tr>
			<td> Date Affectation </td>
			<td> <input type="text" name="dateaffectation"></td>
		</tr>
		<tr>
			<td> Ligne </td>
			<td> <input type="text" name="idligne"></td>
		</tr>
		<tr>
			<td> Bus </td>
			<td> <input type="text" name="idbus"></td>
		</tr>
		<tr>
			<td> Chauffeur </td>
			<td> <input type="text" name="idchauffeur"></td>
		</tr>
		<tr>
			<td> <input type="reset" name="Annuler" value="Annuler"> </td>
			<td> <input type="submit" name="Valider" value="Valider"></td>
		</tr>
	</table> 
</form>
