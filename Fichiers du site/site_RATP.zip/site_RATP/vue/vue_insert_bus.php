<h3> Ajout d'un Bus </h3>
<form method="post">
	<table>
		<tr>
			<td> Matricule </td>
			<td> <input type="text" name="matricule"></td>
		</tr>
		<tr>
			<td> Marque </td>
			<td> <input type="text" name="marque"></td>
		</tr>
		<tr>
			<td> Capacité </td>
			<td> <input type="text" name="capacite"></td>
		</tr>
		<tr>
			<td> Energie </td>
			<td> <input type="text" name="energie"></td>
		</tr>
		<tr>
			<td> <input type="reset" name="Annuler" value="Annuler"> </td>
			<td> <input type="submit" name="Valider" value="Valider"></td>
		</tr>
	</table> 
</form>
