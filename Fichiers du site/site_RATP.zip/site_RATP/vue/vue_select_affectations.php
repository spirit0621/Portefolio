<h3> Liste des Affectations </h3>

<table border="1">
	<tr>
		<td> ID Affectation </td>
		<td> Date Affectation </td>
		<td> Description </td>
		<td> Ligne </td>
		<td> Bus </td> 
		<td> Chauffeur </td>
	</tr>
</table>

 