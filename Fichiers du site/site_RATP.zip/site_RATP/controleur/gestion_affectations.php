<h2> Gestion des affectations </h2>


<?php
	require_once ("vue/vue_insert_affectation.php");

	require_once ("vue/vue_select_affectations.php");
?>