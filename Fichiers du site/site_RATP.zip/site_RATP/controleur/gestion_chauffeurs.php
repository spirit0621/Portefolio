<h2> Gestion des chauffeurs </h2>

<?php
	require_once ("vue/vue_insert_chauffeur.php");
	if (isset($_POST['Valider'])){
		insertChauffeur ($_POST);
		echo "<br> Insertion réussie du Bus.";
	}
	require_once ("vue/vue_select_chauffeurs.php");
?>