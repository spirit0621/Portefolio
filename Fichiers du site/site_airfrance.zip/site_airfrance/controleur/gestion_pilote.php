<h2> Gestion des pilote </h2>

<?php
$lePilote = null; 
if((isset($_GET['action']))&&(isset($_GET['idpilote'])))
{
	$action = $_GET['action']; 
	$idpilote = $_GET['idpilote']; 
	switch ($action){
		case "sup" : deletePilote ($idpilote) ; 
		break; 
		case "edit" : $lePilote = selectWherePilote($idpilote); 
		break;
	}
}
require_once("vue/vue_insert_pilote.php");
if (isset($_POST['Valider'])) {
	//insertion de pilotes dans la table pilotes
	insertPilote($_POST);
	echo "<br> Insertion de pilotes réussie.";
}
if (isset($_POST['Modifier']))
{
	updatePilote ($_POST);
	//recharger la page 
	header(("location: index.php?page=2"));
}
$lesPilotes = selectAllPilotes (); 
require_once ("vue/vue_select_pilote.php");
if (isset($_POST['Modifier'])) {
	updatePilote($_POST); // recharger la page
	header(("location: index.php?page=2"));
}

?>