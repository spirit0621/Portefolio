<h2> Gestion des vols </h2>


<?php
$leVol = null;
if (isset($_GET['action']) && isset($_GET['idvol'])) {
	$action = $_GET['action'];
	$idvol = $_GET['idvol'];
	switch ($action) {
		case "sup":
			deleteVol($idvol);
			break;
		case "edit":
			$leVol = selectWhereVol($idvol);
			break;
	}
}

require_once("vue/vue_insert_vol.php");
if (isset($_POST['Valider'])) {
	//insertion de vols dans la table vols
	insertVol($_POST);
	echo "<br> Insertion de vols réussie.";
}
$lesVols = selectAllVols();
require_once("vue/vue_select_vol.php");

if (isset($_POST['Modifier'])) {
	updateVol($_POST); // recharger la page
	header(("location: index.php?page=4"));
}
?>