<h3> Liste des Vols </h3>

<table border="1">
	<tr>
		<td> ID Vol </td>
		<td> Désignation </td>
		<td> Date Vol </td>
		<td> Heure Vol </td>
		<td> ID Pilote 1 </td>
		<td> ID Pilote 2 </td>
		<td> ID Avion </td>
		<td> operations </td>
	</tr>

	<?php
	foreach ($lesVols as $unVol) {
		echo "<tr>";
		echo "<td>" . $unVol['idvol'] . "</td>";
		echo "<td>" . $unVol['designation'] . "</td>";
		echo "<td>" . $unVol['datevol'] . "</td>";
		echo "<td>" . $unVol['heurevol'] . "</td>";
		echo "<td>" . $unVol['idpilote1'] . "</td>";
		echo "<td>" . $unVol['idpilote2'] . "</td>";
		echo "<td>" . $unVol['idavion'] . "</td>";
		echo "<td>";
		echo "<a href='index.php?page=4&action=sup&idvol=" . $unVol['idvol'] . "'><img src='images/sup.png' height='50'/> </a>";
		echo "<a href='index.php?page=4&action=edit&idvol=" . $unVol['idvol'] . "'><img src='images/edit.png' height='50'/> </a>";
		"</td>";
		echo "</tr>";
	}
	?>
</table>