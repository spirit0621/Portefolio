<h3> Ajout d'un avion </h3>
<form method="post">
    <table>
        <tr>
            <td> Désignation </td>
            <td> <input type="text" name="designation"
            value="<?php if($leAvion!=null) echo $leAvion['designation'] ?>"></td>
        </tr>
        <tr>
            <td> Constructeur </td>
            <td> <input type="text" name="constructeur"
            value="<?php if($leAvion!=null) echo $leAvion['constructeur'] ?>"></td>
        </tr>
        <tr>
            <td> Nombre de places </td>
            <td> <input type="text" name="nbplaces"
            value="<?php if($leAvion!=null) echo $leAvion['nbplaces'] ?>"></td>
        </tr>
        <tr>
            <td> <input type="reset" name="Annuler" value="Annuler"> </td>
            <td> <input type="submit" 
            <?php if($leAvion !=null) {
				echo ' name = "Modifier" value = "Modifier" ';
			}else {
				echo 'name="Valider" value="Valider"';
			}
			?>
            > </td>
        </tr>
    </table>
    <?php 
	if($leAvion !=null) {
		echo "<input type ='hidden' name='idavion' value ='".$leAvion['idavion']."'>";
	}
	?>
</form>