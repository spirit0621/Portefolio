<?php
/*
	dans ce fichier, on réalise toutes les fonctions de connexion à la BDD, deconnexion de la BDD et exécution de l'ensemble des requetes sur les tables de la BDD : insert, delete, update, select.
	*/

function connexion()
{
	$connexion = mysqli_connect("localhost:3306", "root", "", "air_france_284");
	if ($connexion == null) {
		echo "Erreur de connexion au serveur Mysql.";
	}
	return $connexion;
}
function deconnexion($connexion)
{
	mysqli_close($connexion);
}
/***************** Gestion des Pilotes *******/
function insertPilote($tab)
{
	$requete = "insert into pilote values (null, '"
		. $tab['nom'] . "','"
		. $tab['prenom'] . "','"
		. $tab['email'] . "','"
		. $tab['mdp'] . "','"
		. $tab['bip'] . "','"
		. $tab['statut'] . "' ) ; ";

	$con = connexion(); //appel de la connexion 
	mysqli_query($con, $requete); //execution de la requete
	deconnexion($con); //deconnexion de la base de données
}
function selectAllPilotes()
{
	$requete = "select * from pilote;";
	$con = connexion();
	$lesPilotes = mysqli_query($con, $requete);
	deconnexion($con);
	return $lesPilotes;
}
function deletePilote ($idpilote){
	$requete = "delete from pilote where idpilote=".$idpilote;
	$con = connexion();
	mysqli_query($con, $requete);
	deconnexion ($con);
}
function updatePilote ($tab){
	$requete = "update pilote set nom='"
	.$tab['nom']."' ,prenom='"
	.$tab['prenom']."' ,email='"
	.$tab['email']."' ,mdp='"
	.$tab['mdp']."' ,bip='"
	.$tab['bip']."' ,statut='"
	.$tab['statut']."' where idpilote="
	.$tab['idpilote'];

	$con = connexion();
	mysqli_query($con, $requete);
	deconnexion ($con);
}
function selectWherePilote ($idpilote){
	$requete = "select * from pilote where idpilote=".$idpilote;
	
	$con = connexion();
	$resultats = mysqli_query($con, $requete);
	$lePilote = mysqli_fetch_assoc($resultats);
	deconnexion ($con);
	return $lePilote;
}
//gestion des avions
function insertAvion($tab)
{
	$requete = "insert into avion values (null, '"
		. $tab['designation'] . "','"
		. $tab['constructeur'] . "','"
		. $tab['nbplaces'] . "' ) ; ";

	$con = connexion(); //appel de la connexion 
	mysqli_query($con, $requete); //execution de la requete
	deconnexion($con); //deconnexion de la base de données
}
function selectAllAvions()
{
	$requete = "select * from avion;";
	$con = connexion();
	$lesAvions = mysqli_query($con, $requete);
	deconnexion($con);
	return $lesAvions;
}
function deleteAvion ($idavion){
	$requete = "delete from avion where idavion=".$idavion;
	$con = connexion();
	mysqli_query($con, $requete);
	deconnexion ($con);
}
function updateAvion ($tab){
	$requete = "update avion set designation='"
	.$tab['designation']."' ,constructeur='"
	.$tab['constructeur']."' ,nbplaces='"
	.$tab['nbplaces']."' where idavion="
	.$tab['idavion'];

	$con = connexion();
	mysqli_query($con, $requete);
	deconnexion ($con);
}
function selectWhereAvion ($idavion){
	$requete = "select * from avion where idavion=".$idavion;
	
	$con = connexion();
	$resultats = mysqli_query($con, $requete);
	$leAvion = mysqli_fetch_assoc($resultats);
	deconnexion ($con);
	return $leAvion;
}
//gestion des vols
function insertVol($tab)
{
	$requete = "insert into vol values (null, '"
		. $tab['designation'] . "','"
		. $tab['datevol'] . "','"
		. $tab['heurevol'] . "','"
		. $tab['idpilote1'] . "','"
		. $tab['idpilote2'] . "','"
		. $tab['idavion'] . "' ) ; ";
	$con = connexion(); //appel de la connexion 
	mysqli_query($con, $requete); //execution de la requete
	deconnexion($con); //deconnexion de la base de données
}
function selectAllVols()
{
	$requete = "select * from vol;";
	$con = connexion();
	$lesVols = mysqli_query($con, $requete);
	deconnexion($con);
	return $lesVols;
}
function deleteVol ($idvol){
	$requete = "delete from vol where idvol=".$idvol;
	$con = connexion();
	mysqli_query($con, $requete);
	deconnexion ($con);
}
function updateVol ($tab){
	$requete = "update vol set designation='"
	.$tab['designation']."' ,datevol='"
	.$tab['datevol']."' ,heurevol='"
	.$tab['heurevol']."' ,idpilote1='"
	.$tab['idpilote1']."' ,idpilote2='"
	.$tab['idpilote2']."' where idvol="
	.$tab['idvol'];

	$con = connexion();
	mysqli_query($con, $requete);
	deconnexion ($con);
}
function selectWhereVol ($idvol){
	$requete = "select * from vol where idvol=".$idvol;
	
	$con = connexion();
	$resultats = mysqli_query($con, $requete);
	$leVol = mysqli_fetch_assoc($resultats);
	deconnexion ($con);
	return $leVol;
}
